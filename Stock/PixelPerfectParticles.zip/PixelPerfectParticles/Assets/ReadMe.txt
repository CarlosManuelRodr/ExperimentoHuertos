Demo scene is located inside the /Scenes/ folder.

Warcher Defenders development blog
http://warcher-devlog.tumblr.com/

Ogre Pixel
http://ogrepixel.com/